from tkinter import*
import random
import time;
import datetime
from tkinter import Tk, StringVar, ttk


root=Tk()
root.geometry("1350x750+0+0")
root.title("Fast Food Resaurant ordering system")

Tops = Frame (root, width = 1350 , height=100, bd= 12, relief="raise")
Tops.pack(side=TOP)
lblTitle = Label(Tops, font=('Times new roman', 50, 'bold'), text="\t McDonald's Fast Food restaurant\t\t\t")
lblTitle.grid(row =0, column=0)

BottomMainFrame = Frame (root, width = 1350 , height=650, bd= 12, relief="raise")
BottomMainFrame.pack(side=BOTTOM)

f1 = Frame (BottomMainFrame, width = 450 , height=650, bd= 12, relief="raise")
f1.pack(side=LEFT)
f2 = Frame (BottomMainFrame, width = 450 , height = 650, bd= 12, relief="raise")
f2.pack(side=LEFT)
f2TOP = Frame (f2, width = 450 , height=350, bd= 4, relief="raise")
f2TOP.pack(side=TOP)
f2BOTTOM = Frame (f2, width = 450 , height=300, bd= 4, relief="raise")
f2BOTTOM.pack(side=BOTTOM)

f3 = Frame (BottomMainFrame, width = 450 , height=650, bd= 12, relief="raise")
f3.pack(side=RIGHT)

var1=IntVar()
var2=IntVar()
var3=IntVar()
var4=IntVar()
var5=IntVar()
var6=IntVar()
var7=IntVar()
var8=IntVar()
var9=IntVar()
var10=IntVar()
var11=IntVar()
var12=IntVar()
var13=IntVar()
var14=IntVar()
var15=IntVar()
var16=IntVar()
var17=IntVar()
var18=IntVar()
var19=IntVar()
var20=IntVar()
var21=IntVar()
var22=IntVar()
var23=IntVar()

var1.set(0)
var2.set(0)
var3.set(0)
var4.set(0)
var5.set(0)
var6.set(0)
var7.set(0)
var8.set(0)
var9.set(0)
var10.set(0)
var11.set(0)
var12.set(0)
var13.set(0)
var14.set(0)
var15.set(0)
var16.set(0)
var17.set(0)
var18.set(0)
var19.set(0)
var20.set(0)
var21.set(0)
var22.set(0)
var23.set(0)

varBigMac=StringVar()
varQuarterPounderwithCheese=StringVar()
varDoubleQuarterPounderwithCheese=StringVar()
varMcDouble=StringVar()
varCheeseburger=StringVar()

varBigMac.set("0")
varQuarterPounderwithCheese.set("0")
varDoubleQuarterPounderwithCheese.set("0")
varMcDouble.set("0")
varCheeseburger.set("0")

lblMeal = Label(f1, font=('Times new roman', 18, 'bold'), text="Burgers")
lblMeal.grid(row =0, column=0)

BigMac =Checkbutton(f1, text="BigMac", variable=var1, onvalue=1, offvalue=0, font=('Times new roman',18, 'bold')).grid(row=1, column=0, sticky=W)

txtBigMac = Entry(f1, font=('Times new roman', 18, 'bold'), textvariable=varBigMac, width =6, justify='left', state =DISABLED)
txtBigMac.grid(row =1, column=1)

QuarterPounderwithCheese =Checkbutton(f1, text="QuarterPounderwithCheese", variable=var2, onvalue=1, offvalue=0, font=('Times new roman',18, 'bold')).grid(row=2, column=0, sticky=W)

txtQuarterPounderwithCheese = Entry(f1, font=('Times new roman', 18, 'bold'), textvariable=varQuarterPounderwithCheese, width =6,  justify='left', state =DISABLED)
txtQuarterPounderwithCheese.grid(row =2, column=1)

DoubleQuarterPounderwithCheese =Checkbutton(f1, text="DoubleQuarterPounderwithCheese", variable=var3, onvalue=1, offvalue=0, font=('Times new roman',18, 'bold')).grid(row=3, column=0, sticky=W)

txtDoubleQuarterPounderwithCheese = Entry(f1, font=('Times new roman', 18, 'bold'), textvariable=varDoubleQuarterPounderwithCheese, width =6, justify='left', state =DISABLED)
txtDoubleQuarterPounderwithCheese.grid(row =3, column=1)

McDouble =Checkbutton(f1, text="Mcdouble", variable=var4, onvalue=1, offvalue=0, font=('Times new roman',18, 'bold')).grid(row=4, column=0, sticky=W)

txtMcDouble = Entry(f1, font=('Times new roman', 18, 'bold'), textvariable=varMcDouble, width =6,  justify='left', state =DISABLED)
txtMcDouble.grid(row =4, column=1)

CheeseBurger =Checkbutton(f1, text="CheeseBurger", variable=var5, onvalue=1, offvalue=0, font=('Times new roman',18, 'bold')).grid(row=5, column=0, sticky=W)

txtCheeseBurger = Entry(f1, font=('Times new roman', 18, 'bold'), textvariable=varCheeseburger, width =6,  justify='left', state =DISABLED)
txtCheeseBurger.grid(row =5, column=1)

lblspace=Label( f1, text="\n\n\n\n\n\n\n\n\n")
lblspace.grid(row=6, column=0)

root.mainloop()