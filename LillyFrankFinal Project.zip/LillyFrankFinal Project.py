from re import I
from tkinter import*
import random
import time;
import datetime
from tkinter import messagebox
from tkinter import Tk, StringVar, ttk


root=Tk()
root.geometry("1550x750+0+0")
root.title("Fast Food Resaurant ordering system")

Tops = Frame (root, width = 1350 , height=100, bd= 6, relief="raise")
Tops.pack(side=TOP)
lblTitle = Label(Tops, font=('arial', 50, 'bold'), text="\t McDonald's Fast Food restaurant\t\t\t")
lblTitle.grid(row =0, column=0)

BottomMainFrame = Frame (root, width = 1350 , height=650, bd= 6, relief="raise")
BottomMainFrame.pack(side=BOTTOM)

f1 = Frame (BottomMainFrame, width = 450 , height= 650, bd= 2, relief="raise")
f1.pack(side=LEFT)
f2 = Frame (BottomMainFrame, width = 450 , height = 650, bd= 2, relief="raise")
f2.pack(side=LEFT)
f2TOP = Frame (f2, width = 450 , height=650, bd= 2, relief="raise")
f2TOP.pack(side=TOP)
f2BOTTOM = Frame (f2, width = 450 , height=300, bd= 1, relief="raise")
f2BOTTOM.pack(side=BOTTOM)

f3 = Frame (BottomMainFrame, width = 450 , height=650, bd= 0, relief="raise")
f3.pack(side=RIGHT)

# declared variables
var1=IntVar()
var2=IntVar()
var3=IntVar()
var4=IntVar()
var5=IntVar()
var6=IntVar()
var7=IntVar()
var8=IntVar()
var9=IntVar()
var10=IntVar()
var11=IntVar()
var12=IntVar()
var13=IntVar()
var14=IntVar()
var15=StringVar()

var1.set(0)
var2.set(0)
var3.set(0)
var4.set(0)
var5.set(0)
var6.set(0)
var7.set(0)
var8.set(0)
var9.set(0)
var10.set(0)
var11.set(0)
var12.set(0)
var13.set(0)
var14.set(0)
var15.set(0)


varBigMac=StringVar()
varQuarterPounderwithCheese=StringVar()
varDoubleQuarterPounderwithCheese=StringVar()
varMcDouble=StringVar()
varCheeseburger=StringVar()

varSausageMcMuffin=StringVar()
varSausageBurrito=StringVar()
varHashBrowns=StringVar()
varSausageBiscuit=StringVar()

varIcedCoffee=StringVar()
varSweetTea=StringVar()
varSoftDrink=StringVar()
varOrangeJuice=StringVar()
varMilk=StringVar()

varVAT=StringVar()
varTAX=StringVar()
varChange=StringVar()
varSubTotal=StringVar()
varTotal=StringVar()
varPayment= IntVar()

varBigMac.set("0")
varQuarterPounderwithCheese.set("0")
varDoubleQuarterPounderwithCheese.set("0")
varMcDouble.set("0")
varCheeseburger.set("0")
varTotal.set("0")
varPayment.set("0")

varSausageMcMuffin.set("0")
varSausageBurrito.set("0")
varHashBrowns.set("0")
varSausageBiscuit.set("0")

varIcedCoffee.set("0")
varSweetTea.set("0")
varSoftDrink.set("0")
varOrangeJuice.set("0")
varMilk.set("0")

varVAT.set("")
varTAX.set("0")
varTotal.set("0")
varChange.set("0")
varSubTotal.set("0")

# Creating commands for the total, reset and exit buttons, as well as creating commands for the checkboxes
def iExit():
    qExit= messagebox.askyesno("Mcdonald's","Do you want to quit")
    if qExit > 0:
        root.destroy()
        return

def Reset ():
    varBigMac.set("0")
    varQuarterPounderwithCheese.set("0")
    varDoubleQuarterPounderwithCheese.set("0")
    varMcDouble.set("0")
    varCheeseburger.set("0")
    varTotal.set("0")

    varSausageMcMuffin.set("0")
    varSausageBurrito.set("0")
    varHashBrowns.set("0")
    varSausageBiscuit.set("0")

    varIcedCoffee.set("0")
    varSweetTea.set("0")
    varSoftDrink.set("0")
    varOrangeJuice.set("0")
    varMilk.set("0")

    varVAT.set("")
    varTAX.set("0")
    varTotal.set("0")
    varChange.set("0")
    varSubTotal.set("0")
    varPayment.set("")

    var1.set(0)
    var2.set(0)
    var3.set(0)
    var4.set(0)
    var5.set(0)
    var6.set(0)
    var7.set(0)
    var8.set(0)
    var9.set(0)
    var10.set(0)
    var11.set(0)
    var12.set(0)
    var13.set(0)
    var14.set(0)    


    txtBigMac.configure(state =DISABLED)
    txtQuarterPounderwithCheese.configure(state =DISABLED)
    txtDoubleQuarterPounderwithCheese.configure(state =DISABLED)
    txtMcDouble.configure(state =DISABLED)
    txtCheeseBurger.configure(state =DISABLED)
    txtSausageMcMuffin.configure(state =DISABLED)
    txtSausageBurrito.configure(state =DISABLED)
    txtHashBrowns.configure(state =DISABLED)
    txtSausageBiscuit.configure(state =DISABLED)
    txtIcedCoffee.configure(state =DISABLED)
    txtSweetTea.configure(state =DISABLED)
    txtSoftDrink.configure(state =DISABLED)
    txtOrangeJuice.configure(state =DISABLED)
    txtMilk.configure(state =DISABLED)
    txtChange.configure(state =DISABLED)
    txtTax.configure(state =DISABLED)
    txtSubTotal.configure(state =DISABLED)
    txtTotal.configure(state =DISABLED)

    

def chkBigMac():
    if (var1.get() == 1):
        txtBigMac.configure(state =NORMAL)
        varBigMac.set("")
    elif (var1.get() == 0):
        txtBigMac.configure(state =DISABLED)
        varBigMac.set("0")

def chkQuarterPounderwithCheese():
    if (var2.get() == 1):
        txtQuarterPounderwithCheese.configure(state =NORMAL)
        varQuarterPounderwithCheese.set("")
    elif (var2.get() == 0):
        txtQuarterPounderwithCheese.configure(state =DISABLED)
        varQuarterPounderwithCheese.set("0")

def chkDoubleQuarterPounderwithCheese():
    if (var3.get() == 1):
        txtDoubleQuarterPounderwithCheese.configure(state =NORMAL)
        varDoubleQuarterPounderwithCheese.set("")
    elif (var3.get() == 0):
        txtDoubleQuarterPounderwithCheese.configure(state =DISABLED)
        varDoubleQuarterPounderwithCheese.set("0")

def chkMcDouble():
    if (var4.get() == 1):
        txtMcDouble.configure(state =NORMAL)
        varMcDouble.set("")
    elif (var4.get() == 0):
        txtMcDouble.configure(state =DISABLED)
        varMcDouble.set("0")

def chkCheeseBurger():
    if (var5.get() == 1):
        txtCheeseBurger.configure(state =NORMAL)
        varCheeseburger.set("")
    elif (var5.get() == 0):
        txtCheeseBurger.configure(state =DISABLED)
        varCheeseburger.set("0")

def chkSausageMcMuffin():
    if (var6.get() == 1):
        txtSausageMcMuffin.configure(state =NORMAL)
        varSausageMcMuffin.set("")
    elif (var6.get() == 0):
        txtSausageMcMuffin.configure(state =DISABLED)
        varSausageMcMuffin.set("0")

def chkSausageBurrito():
    if (var7.get() == 1):
        txtSausageBurrito.configure(state =NORMAL)
        varSausageBurrito.set("")
    elif (var7.get() == 0):
        txtSausageBurrito.configure(state =DISABLED)
        varSausageBurrito.set("0")

def chkHashBrowns():
    if (var8.get() == 1):
        txtHashBrowns.configure(state =NORMAL)
        varHashBrowns.set("")
    elif (var8.get() == 0):
        txtHashBrowns.configure(state =DISABLED)
        varHashBrowns.set("0")

def chkSausageBiscuit():
    if (var9.get() == 1):
        txtSausageBiscuit.configure(state =NORMAL)
        varSausageBiscuit.set("")
    elif (var9.get() == 0):
        txtSausageBiscuit.configure(state =DISABLED)
        varSausageBiscuit.set("0")

def chkIcedCoffee():
    if (var10.get() == 1):
        txtIcedCoffee.configure(state =NORMAL)
        varIcedCoffee.set("")
    elif (var10.get() == 0):
        txtIcedCoffee.configure(state =DISABLED)
        varIcedCoffee.set("0")

def chkSweetTea():
    if (var11.get() == 1):
        txtSweetTea.configure(state =NORMAL)
        varSweetTea.set("")
    elif (var11.get() == 0):
        txtSweetTea.configure(state =DISABLED)
        varSweetTea.set("0")

def chkSoftDrink():
    if (var12.get() == 1):
        txtSoftDrink.configure(state =NORMAL)
        varSoftDrink.set("")
    elif (var12.get() == 0):
        txtSoftDrink.configure(state =DISABLED)
        varSoftDrink.set("0")

def chkOrangeJuice():
    if (var13.get() == 1):
        txtOrangeJuice.configure(state =NORMAL)
        varOrangeJuice.set("")
    elif (var13.get() == 0):
        txtOrangeJuice.configure(state =DISABLED)
        varOrangeJuice.set("0")

def chkMilk():
    if (var14.get() == 1):
        txtMilk.configure(state =NORMAL)
        varMilk.set("")
    elif (var14.get() == 0):
        txtMilk.configure(state =DISABLED)
        varMilk.set("0")

def costofmeal ():
    meal1 = float(varBigMac.get())
    meal2 = float(varQuarterPounderwithCheese.get())
    meal3 = float(varDoubleQuarterPounderwithCheese.get())
    meal4 = float(varMcDouble.get())
    meal5 = float(varCheeseburger.get())
    meal6 = float(varSausageMcMuffin.get())
    meal7 = float(varSausageBurrito.get())
    meal8 = float(varHashBrowns.get())
    meal9 = float(varSausageBiscuit.get())
    meal10 = float(varIcedCoffee.get())
    meal11 = float(varSweetTea.get())
    meal12 = float(varSoftDrink.get())
    meal13 = float(varOrangeJuice.get())
    meal14 = float(varMilk.get())

    iTotal1=((meal1 * 3.99) + (meal2 * 3.79) + (meal3 * 4.79) + (meal4 * 1.39) + (meal5 * 1.00))
    iTotal2=((meal6 * 1.19) + (meal7 * 1.29) + (meal8 * 1.09) + (meal9 * 1.19))
    iTotal3=((meal10 * 1.39) + (meal11 * 1.00) + (meal12 * 1.00) + (meal13 * 1.59) + (meal14 * 1.00))

# as a note, the tax is the indiana state tax, and when you run the program, the box below the list of payment methods is were you put the amount of cash for the change value when you select cash as the payment method
    if (var15.get() == "Cash"):
        iChange = float(varPayment.get())
        iCost = (iTotal1 + iTotal2 + iTotal3)
        iTax = (iCost * 0.1)
        iTaxq ='$' + str('%.2f'%(iTax))
        varTAX.set(iTaxq)
        iCostq = '$' + str('%.2f'%(iCost))
        varSubTotal.set(iCostq)
        iTotalq = '$' + str('%.2f'%((iCost + iTax)))
        varTotal.set(iTotalq)
        cChange = (iChange - (iCost + iTax))
        cChangeq = '$' + str('%.2f'%(cChange))
        varChange.set(cChangeq)
    elif(var15.get() == "Master Card" or "Visa Card" or "Debit Card"):
        varPayment.set("")
        iCost = (iTotal1 + iTotal2 + iTotal3)
        iTax = (iCost * 0.1)
        iTaxq = '$' + str('%.2f'%(iTax))
        varTAX.set(iTaxq)
        iCostq = '$' + str('%.2f'%(iCost))
        varSubTotal.set(iCostq)
        iTotalq = '$' + str('%.2f'%((iCost + iTax)))
        varTotal.set(iTotalq)
        varChange.set("")

# first Frame that has the burger meals
lblMeal = Label(f1, font=('arial', 18, 'bold'), text="Burgers")
lblMeal.grid(row =0, column=0)

BigMac =Checkbutton(f1, text="BigMac\t\t\t\t$3.99", variable=var1, onvalue=1, offvalue=0, font=('arial',18, 'bold'), command=chkBigMac).grid(row=1, column=0, sticky=W)

txtBigMac = Entry(f1, font=('arial', 18, 'bold'), textvariable=varBigMac, width =6, justify='left', state =DISABLED)
txtBigMac.grid(row =1, column=1)

QuarterPounderwithCheese =Checkbutton(f1, text="QuarterPounderwithCheese\t$3.79", variable=var2, onvalue=1, offvalue=0, font=('arial',18, 'bold'), command=chkQuarterPounderwithCheese).grid(row=2, column=0, sticky=W)

txtQuarterPounderwithCheese = Entry(f1, font=('arial', 18, 'bold'), textvariable=varQuarterPounderwithCheese, width =6,  justify='left', state =DISABLED)
txtQuarterPounderwithCheese.grid(row =2, column=1)

DoubleQuarterPounderwithCheese =Checkbutton(f1, text="DoubleQuarterPounderwithCheese\t$4.79", variable=var3, onvalue=1, offvalue=0, font=('arial',18, 'bold'), command=chkDoubleQuarterPounderwithCheese).grid(row=3, column=0, sticky=W)

txtDoubleQuarterPounderwithCheese = Entry(f1, font=('arial', 18, 'bold'), textvariable=varDoubleQuarterPounderwithCheese, width =6, justify='left', state =DISABLED)
txtDoubleQuarterPounderwithCheese.grid(row =3, column=1)

McDouble =Checkbutton(f1, text="Mcdouble\t\t\t$1.39", variable=var4, onvalue=1, offvalue=0, font=('arial',18, 'bold'), command=chkMcDouble).grid(row=4, column=0, sticky=W)

txtMcDouble = Entry(f1, font=('arial', 18, 'bold'), textvariable=varMcDouble, width =6,  justify='left', state =DISABLED)
txtMcDouble.grid(row =4, column=1)

CheeseBurger =Checkbutton(f1, text="CheeseBurger\t\t\t$1.00", variable=var5, onvalue=1, offvalue=0, font=('arial',18, 'bold'), command=chkCheeseBurger).grid(row=5, column=0, sticky=W)

txtCheeseBurger = Entry(f1, font=('arial', 18, 'bold'), textvariable=varCheeseburger, width =6,  justify='left', state =DISABLED)
txtCheeseBurger.grid(row =5, column=1)

lblspace=Label( f1, text="\n\n\n\n\n\n\n\n\n")
lblspace.grid(row=6, column=0)

# Second Frame that has the breakfast meals
lblMeal = Label(f2TOP, font=('arial', 18, 'bold'), text="Breakfast\n")
lblMeal.grid(row =0, column=0)

SausageMcMuffin =Checkbutton(f2TOP, text="SausageMcMuffin\t\t$1.19", variable=var6, onvalue=1, offvalue=0, font=('arial',18,'bold'), comman=chkSausageMcMuffin).grid(row=1, column=0, sticky=W)

txtSausageMcMuffin = Entry(f2TOP,font=('arial',18,'bold'), textvariable =varSausageMcMuffin, width=6, justify="right", state =DISABLED)
txtSausageMcMuffin.grid(row=1, column=1)

SausageBurrito =Checkbutton(f2TOP, text="SausageBurrito\t\t$1.29", variable=var7, onvalue=1, offvalue=0, font=('arial',18,'bold'), command=chkSausageBurrito).grid(row=2, column=0, sticky=W)

txtSausageBurrito = Entry(f2TOP,font=('arial',18,'bold'), textvariable =varSausageBurrito, width=6, justify="right", state =DISABLED)
txtSausageBurrito.grid(row=2, column=1)

HashBrowns =Checkbutton(f2TOP, text="HashBrowns\t\t$1.09", variable=var8, onvalue=1, offvalue=0, font=('arial',18,'bold'), command=chkHashBrowns).grid(row=3, column=0, sticky=W)

txtHashBrowns = Entry(f2TOP,font=('arial',18,'bold'), textvariable =varHashBrowns, width=6, justify="right", state =DISABLED)
txtHashBrowns.grid(row=3, column=1)

SausageBiscuit =Checkbutton(f2TOP, text="SausageBiscuit\t\t$1.19", variable=var9, onvalue=1, offvalue=0, font=('arial',18,'bold'), command=chkSausageBiscuit).grid(row=4, column=0, sticky=W)

txtSausageBiscuit = Entry(f2TOP,font=('arial',18,'bold'), textvariable =varSausageBiscuit, width=6, justify="right", state =DISABLED)
txtSausageBiscuit.grid(row=4, column=1)

# Third Frame that has the drinks you can buy
lblMeal = Label(f3,font=('arial', 18, 'bold'), text="Drinks\n")
lblMeal.grid(row =0, column=0)

IcedCoffee =Checkbutton(f3, text="IcedCoffee\t$1.39", variable=var10, onvalue =1, offvalue=0,font=('arial',18,'bold'), command=chkIcedCoffee).grid(row=1, column=0, sticky=W)

txtIcedCoffee = Entry(f3,font=('arial',18,'bold'), textvariable =varIcedCoffee, width =6, justify="right", state=DISABLED)
txtIcedCoffee.grid(row =1, column=1)

SweetTea =Checkbutton(f3, text="SweetTea\t$1.00", variable=var11, onvalue =1, offvalue=0,font=('arial',18,'bold'), command=chkSweetTea).grid(row=2, column=0, sticky=W)

txtSweetTea = Entry(f3,font=('arial',18,'bold'), textvariable =varSweetTea, width =6, justify="right", state=DISABLED)
txtSweetTea.grid(row =2, column=1)

SoftDrink =Checkbutton(f3, text="SoftDrink\t$1.00", variable=var12, onvalue =1, offvalue=0,font=('arial',18,'bold'), command=chkSoftDrink).grid(row=3, column=0, sticky=W)

txtSoftDrink = Entry(f3,font=('arial',18,'bold'), textvariable =varSoftDrink, width =6, justify="right", state=DISABLED)
txtSoftDrink.grid(row =3, column=1)

OrangeJuice =Checkbutton(f3, text="OrangeJuice\t$1.59", variable=var13, onvalue =1, offvalue=0,font=('arial',18,'bold'), command=chkOrangeJuice).grid(row=4, column=0, sticky=W)

txtOrangeJuice = Entry(f3,font=('arial',18,'bold'), textvariable =varOrangeJuice, width =6, justify="right", state=DISABLED)
txtOrangeJuice.grid(row =4, column=1)

Milk =Checkbutton(f3, text="Milk\t\t$1.00", variable=var14, onvalue =1, offvalue=0,font=('arial',18,'bold'), command=chkMilk).grid(row=5, column=0, sticky=W)

txtMilk = Entry(f3,font=('arial',18,'bold'), textvariable =varMilk, width =6, justify="right", state=DISABLED)
txtMilk.grid(row =5, column=1)

lblsapce=Label( f3, text="\n\n\n\n\n\n\n\n\n")
lblspace.grid(row=6, column=0)

# Payment Frame for the total cost
lblPaymentMethod = Label(f2BOTTOM, font=('arial',14, 'bold'), text="Payment Method", bd=10, width= 16, anchor='w')
lblPaymentMethod.grid(row=0,column=0)

lblChange = Label(f2BOTTOM, font=('arial',14,'bold'), text="Change", bd=10, anchor='w')
lblChange.grid(row=4,column=1)
txtChange = Entry(f2BOTTOM,font=('arial',18,'bold'), textvariable =varChange, width =6, justify='right',  state =DISABLED)
txtChange.grid(row =4, column=2)

cmbPaymentMethod = ttk.Combobox(f2BOTTOM, textvariable = var15, state='readonly', font=('arial',10,'bold'), width= 20)
cmbPaymentMethod['value']=('Cash', 'Master Card', 'Visa Card', 'Debit Card')
cmbPaymentMethod.current(0)
cmbPaymentMethod.grid(row=1,column=0)

lblTax = Label(f2BOTTOM, font=('arial', 14,'bold'), text="Tax   ", bd=10, anchor='w')
lblTax.grid(row=1,column=1)
txtTax = Entry(f2BOTTOM,font=('arial',18,'bold'), textvariable=varTAX, width=6, justify="right", state =DISABLED)
txtTax.grid(row =1, column =2)

txtPayment = Entry(f2BOTTOM,font=('arial',18,'bold'), textvariable=varPayment, width =6, justify="right") #state =DISABLED)
txtPayment.grid(row =2, column =0)
lblSubTotal = Label(f2BOTTOM, font=('arial',14,'bold'), text="Sub Total", bd=10, width=8, anchor="w")
lblSubTotal.grid(row=2, column=1)
txtSubTotal = Entry(f2BOTTOM,font=('arial',18,'bold'), textvariable=varSubTotal, width=6, justify="right", state =DISABLED)
txtSubTotal.grid(row =2, column =2)

lblTotal =Label(f2BOTTOM, font=('arial',14,'bold'), text="Total", bd=10, width=6,anchor="w")
lblTotal.grid(row=3,column=1)
txtTotal = Entry(f2BOTTOM, font=('arial',18,'bold'), textvariable =varTotal, width =6, justify="right", state =DISABLED)
txtTotal.grid(row =3 , column =2)

# Buttons to exit the application, as well as to caculate the total, and to reset everything
btnTotal=Button(f2BOTTOM,padx=16,pady=1, bd=4, fg="black",font=('arial', 16,'bold'), width=5, text="Total", command = costofmeal).grid(row=6, column=0)

btnReset=Button(f2BOTTOM,padx=16,pady=1, bd=4, fg="black",font=('arial', 16,'bold'), width=5, text="Reset", command =Reset).grid(row=6, column=1)

btnExit=Button(f2BOTTOM,padx=16,pady=1, bd=4, fg="black",font=('arial', 16,'bold'), width=5, text="Exit",command=lambda: iExit()).grid(row=6, column=2)

lblspace=Label(f2BOTTOM, text="\n\n\n\n\n\n\n")
lblspace.grid(row =5, column=0)

root.mainloop()